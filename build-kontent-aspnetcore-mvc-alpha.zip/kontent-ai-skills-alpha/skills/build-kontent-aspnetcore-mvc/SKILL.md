---
name: build-kontent-aspnetcore-mvc
description: Scaffold a new ASP.NET Core MVC application or add Kontent.ai Delivery to an existing MVC application, including current compatible packages, configuration, generated strongly typed content models, source-generated type resolution, and Razor rendering. Use for server-rendered ASP.NET Core MVC app setup; do not use for Web API plus SPA, Blazor, or open-ended site generation from a content model.
---

# Build a Kontent.ai ASP.NET Core MVC application

Create a current, compiling MVC application from the standard .NET template, or integrate Kontent.ai into an existing MVC application. Use framework and Kontent.ai tooling as the deterministic substrate; do not carry or recreate a static starter application.

This workflow requires a supported .NET SDK, NuGet access, and read access to the target Kontent.ai environment.

## Establish the task

Determine:

- whether the target is a new app or an existing MVC project;
- the target project/solution and its repository instructions;
- the Kontent.ai environment ID and whether the environment requires secure Delivery API access;
- whether the user wants plumbing only or a working content slice based on a named content type;
- any explicitly requested .NET or package versions.

Ask only for information that cannot be safely inferred. Treat API keys as secrets. An environment ID is not a Management API project-creation request: this skill reads the content model and content through Delivery tooling and does not create or mutate Kontent.ai environments.

## Inspect before changing

Inspect repository instructions, git status, solution/project layout, target frameworks, installed .NET SDKs, existing package/tool manifests, configuration conventions, and existing Kontent.ai integration. Preserve the established architecture of an existing app unless it is incompatible or the user asks to change it.

For package and framework selection, read [references/scaffold-and-packages.md](references/scaffold-and-packages.md).

## Scaffold or integrate MVC

For a new app, use the current stable `dotnet new mvc` template supported by an installed stable SDK. Do not select a preview SDK or prerelease Kontent.ai package unless the user asks for it or no stable compatible path exists and the user approves the tradeoff.

For an existing app, change only the MVC project and any deliberately separate models project. Do not upgrade its target framework merely to make the newest package installable without the user's approval.

Install a mutually compatible set of:

- `Kontent.Ai.Delivery`;
- `Kontent.Ai.Delivery.SourceGeneration` in the project that compiles the generated models;
- `Kontent.Ai.AspNetCore` for Razor rich-text and asset helpers.

Use the standard .NET configuration system. Bind `AddDeliveryClient` from `DeliveryOptions`. Keep Preview and Secure Access API keys out of tracked settings; use user secrets or deployment environment variables for the application.

## Generate models from the environment

Read [references/model-generation.md](references/model-generation.md), then use `Kontent.Ai.ModelGenerator` as a local .NET tool. Generate Delivery models into a dedicated generated-code directory and an application-specific namespace. Prefer strict nullability unless the user chooses semantic nullability with its projection tradeoff.

Do not edit generated model files. Put extensions in separate partial records. When regenerating, protect hand-written files and identify stale generated files rather than silently leaving invalid model shapes in the project.

Build immediately after generation. Confirm that the source generator sees the attributed models and that typed Delivery queries compile without a manually maintained type-provider registry.

## Wire MVC rendering

Register `IDeliveryClient` through dependency injection and add the Kontent.ai Razor tag helpers in `_ViewImports.cshtml`. Configure rich-text and responsive-image services only to the extent the target app needs them.

Read [references/razor-rendering.md](references/razor-rendering.md) whenever generated models contain rich text or assets, or the user requests embedded-content/link resolution.

## Choose the presentation boundary

Generated content-type records are Delivery element models, not automatically suitable MVC view models.

- If the user asked only for scaffolding and model generation, stop at a clean compiling integration. Do not add empty repository, service, or mapper abstractions merely to fill folders.
- If the user asked for a working page/example, or named a content type, read [references/content-presentation.md](references/content-presentation.md) and implement one vertical slice.
- If multiple content types could plausibly drive the first page and the choice affects routes or UI, ask the user to choose or present a concise recommendation before implementing.
- Do not infer global navigation, URL hierarchy, page composition, or the full site architecture from content-type names alone unless the user explicitly requests a prototype generated from the model.

## Validate and finish

Read [references/validation.md](references/validation.md). At minimum, restore local tools and NuGet packages, regenerate models using the intended command, build the affected solution/project, and inspect the resulting diff for secrets or unrelated changes. Run existing tests and formatting checks when present.

Report:

- the selected target framework and resolved Kontent.ai package/tool versions;
- where configuration belongs and which values remain for the user to supply;
- the generated model namespace/directory and regeneration command;
- any content slice added and the assumptions behind it;
- validation performed and any remaining blocker.
