# Content-to-presentation boundary

Read this only when implementing a working MVC content slice. Do not create these layers for a plumbing-only scaffold.

## Boundary

Generated records describe Delivery element payloads. The SDK returns them inside `IContentItem<T>`, which also carries system metadata. Keep Delivery query/result handling out of controllers and keep generated records out of general-purpose view composition when a view-specific shape is clearer.

Prefer one vertical slice per user-visible feature:

```text
Features/<Feature>/
  <Feature>ContentService.cs
  <Feature>ViewModel.cs
  <Feature>Mapper.cs          # only when mapping is substantial or reused
Controllers/<Feature>Controller.cs
Views/<Feature>/...
```

Match an existing project convention when one exists. Do not introduce a generic repository, unit of work, or universal mapper abstraction solely for Kontent.ai.

## Responsibilities

The feature content service should:

- depend on `IDeliveryClient` through DI;
- build typed queries and pass the request cancellation token;
- apply server-side filters, ordering, projection, depth, and pagination deliberately;
- distinguish a missing item from a failed Delivery request;
- log actionable Delivery errors and return/throw according to the application's existing error policy;
- return view-ready results so the controller remains orchestration-only.

For a small slice, the service can map directly to its view model. Add a mapper class when mapping is shared, complex, or asynchronous. Do not make a synchronous transformation artificially asynchronous.

The controller should:

- validate route/query inputs;
- call the feature service;
- convert a true missing item to `NotFound()`;
- pass a view model to Razor;
- avoid parsing Delivery result envelopes or mapping linked content itself.

## View models

Select only data the view uses. It is appropriate for this MVC-specific layer to retain:

- `IRichTextContent`/`RichTextContent` for `<rich-text>` rendering;
- `IAsset` for `<img-asset>` rendering;
- the content item ID and relevant element codenames when Smart Link/live editing is requested;
- already mapped nested view models for linked items that the view renders.

Do not resolve rich text to a raw HTML string in the mapper by default. Razor's Kontent.ai tag helper is the presentation boundary and can use the configured `IHtmlResolver`. Resolve to `IHtmlContent` only in a view/partial scenario where the extension API is deliberately preferable.

Avoid passing the entire generated element model to a view merely because it is available. Conversely, do not create a view model that mechanically duplicates every generated property without a presentation reason.

## Selecting a first content type

Use a content type named by the user. If the user asks for an example without naming one, inspect generated models and representative content, then recommend a simple type with obvious display fields. Ask before making routing or information-architecture assumptions when more than one choice is plausible.

A first slice may demonstrate a listing and/or detail page, but only when the model actually exposes suitable title, slug, summary, rich-text, and asset elements. Use generated property/codename constants rather than invented field names.

Do not infer a global homepage, navigation tree, URL hierarchy, or component system from content-type names alone.

## Query discipline

- Use typed queries so the source-generated type provider applies the content-type filter.
- Use `WithElements` for listings when the view needs only a subset, while respecting strict-versus-semantic nullability.
- Avoid large `Depth` values as a substitute for understanding linked content.
- Use offset pagination for user-facing lists and feed/continuation APIs for bulk traversal.
- Do not swallow authentication, throttling, or server failures as empty content.

