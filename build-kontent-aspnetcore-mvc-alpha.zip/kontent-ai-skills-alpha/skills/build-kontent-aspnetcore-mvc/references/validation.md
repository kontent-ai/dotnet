# Validation

Validation should prove that the scaffold is reproducible and integrated, not just that files exist.

## Required checks

1. Restore local tools from the repository's manifest.
2. Run the documented model-generation command against the intended environment.
3. Restore NuGet packages and inspect package downgrade/compatibility warnings.
4. Build the affected solution or web/models projects with warnings visible.
5. Run existing tests, format/lint checks, and repository-specific validation when present.
6. Inspect the diff for secrets, generated build output, unintended framework upgrades, and unrelated edits.

Use commands appropriate to the repository, typically:

```bash
dotnet tool restore
dotnet restore
dotnet build --no-restore
dotnet test --no-build
git diff --check
git status --short
```

Do not run `dotnet test --no-build` when the test project was not included in the preceding build. Do not claim runtime connectivity from a compile-only check.

## Integration invariants

Confirm:

- `DeliveryOptions` is bound by `AddDeliveryClient` and required values come from an allowed configuration source;
- no Preview/Secure Access key is tracked;
- generated models are isolated and reproducible;
- `Kontent.Ai.Delivery.SourceGeneration` is referenced by the compilation containing attributed models;
- typed queries compile without a handwritten type registry;
- `_ViewImports.cshtml` enables `Kontent.Ai.AspNetCore` tag helpers;
- any working content slice keeps Delivery result/error handling out of controllers;
- rich text remains structured until Razor resolution;
- the app uses only content types/elements that exist in the generated model.

## Runtime smoke test

When the task includes a functional slice and environment access is available, start the app on an ephemeral local port, request the implemented route, and verify both a successful response and meaningful logs. Stop the process afterward. A successful default MVC homepage proves startup, not Delivery connectivity; say which was tested.

If secure access, network policy, or missing content prevents the runtime check, report that blocker and leave the build green. Do not replace a failed Delivery request with hardcoded sample content to make the smoke test pass.

