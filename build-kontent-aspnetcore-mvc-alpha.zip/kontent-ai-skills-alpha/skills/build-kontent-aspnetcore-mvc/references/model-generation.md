# Generate Delivery models

Use the Kontent.ai Model Generator to turn the target environment's content types into strongly typed Delivery records. Model generation is model-aware but not presentation-aware: it must not infer routes, pages, or navigation.

## Use a local tool

Prefer a repository-local tool manifest so generation is reproducible:

```bash
dotnet new tool-manifest
dotnet tool install Kontent.Ai.ModelGenerator
```

If a manifest already exists, do not create another one. Restore it and install or update only the missing tool as appropriate. For an existing application, keep a compatible pinned tool version unless the user asked for an upgrade.

Run the tool from a directory where the intended `.config/dotnet-tools.json` is in scope:

```bash
dotnet tool run KontentModelGenerator \
  --environmentId "<environment-id>" \
  --namespace "<RootNamespace>.Content.Generated" \
  --outputdir "<absolute-or-correctly-relative-generated-directory>" \
  --nullability strict
```

Use Delivery mode, not Management mode. The environment ID is required. Prefer `strict` nullability because it distinguishes projected-away values from fetched empty values. Use `semantic` only when the user accepts that projection can no longer distinguish those states for non-nullable generated elements.

## Protected environments

The Model Generator currently reads command-line options and an optional `appSettings.json` in its working directory; do not assume it reads application user secrets or process environment variables.

For secure Delivery API access, avoid committing credentials. Prefer an isolated temporary working directory containing a minimally scoped `appSettings.json`, restrict the file permissions, run the local tool with an absolute output directory, and remove the temporary credentials after the command finishes. Do not print the key or include it in the final report. Command-line key arguments are a last resort because they can be exposed through process listings or shell history.

The temporary configuration has this shape:

```json
{
  "DeliveryOptions": {
    "EnvironmentId": "<environment-id>",
    "UseSecureAccess": true,
    "SecureAccessApiKey": "<secure-access-key>"
  },
  "Namespace": "<RootNamespace>.Content.Generated",
  "OutputDir": "<absolute-generated-directory>",
  "Nullability": "strict"
}
```

Use Preview API access only when the user explicitly needs a preview-only content model or the Delivery endpoint requires it.

## Generated-code boundary

Use a dedicated directory such as `Content/Generated`. Generated files contain an auto-generated notice and partial records.

- Never hand-edit generated files.
- Put custom behavior in separate partial-record files outside the generated directory.
- Ensure the project compiling these files references `Kontent.Ai.Delivery.SourceGeneration`.
- Keep all attributed generated models in one compilation for predictable auto-discovery unless the existing solution deliberately registers a custom `ITypeProvider`.
- Do not create or maintain a manual type-provider map when source generation can provide it.

For regeneration in an existing project, generate into a temporary directory first and compare it with the dedicated generated directory. Replace/remove stale files only when the target directory contains exclusively generated files. Preserve partial extensions and any hand-written files elsewhere. Surface content-type renames/removals in the final summary.

## Verify the result

Confirm that:

- every expected model has `[ContentTypeCodename(...)]`;
- the generated namespace matches project conventions;
- the generated records compile against the resolved Delivery packages;
- a typed query such as `GetItems<ChosenType>()` compiles without manual type-provider registration;
- model generation can be repeated with the documented local-tool command.

