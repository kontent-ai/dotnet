# Scaffold and package selection

Use this reference before scaffolding a new MVC project or changing package references.

## Sources of truth

Prefer current primary sources and the actual target project over remembered snippets:

- Delivery SDK: https://github.com/kontent-ai/dotnet/blob/main/src/delivery/README.md
- ASP.NET Core extensions: https://github.com/kontent-ai/dotnet/blob/main/src/aspnetcore/README.md
- Model Generator: https://github.com/kontent-ai/dotnet/blob/main/src/model-generator/README.md
- NuGet package metadata and restore diagnostics for the target framework
- installed SDKs from `dotnet --list-sdks` and the repository's `global.json`, if present

Repository `main` can describe an unreleased version. For ordinary new applications, select the latest stable compatible NuGet packages rather than copying versions from source, samples, or prerelease documentation. Use prereleases only when requested or explicitly approved.

## New application

Use the standard MVC template from an installed stable SDK. Respect a requested name, solution layout, authentication mode, and target framework. Otherwise select the current supported stable framework available locally.

Typical shape:

```bash
dotnet new sln --name <SolutionName>
dotnet new mvc --name <ProjectName> --framework <TargetFramework>
dotnet sln add <ProjectName>/<ProjectName>.csproj
```

Do not add styling systems, JavaScript frameworks, persistence, authentication, caching, webhooks, Smart Link, or preview plumbing unless requested.

## Existing application

Inspect all of the following before choosing versions:

- `TargetFramework`/`TargetFrameworks` and `global.json`;
- `Directory.Packages.props` or other central package management;
- current Kontent.ai package references, including transitive versions;
- whether generated models compile in the web project or a class library;
- existing configuration section names and DI registration.

Preserve central package management. Do not add inline `Version` attributes when the repository centrally manages them. Do not upgrade the target framework or unrelated packages as an incidental fix.

## Package policy

For a new integration, add the latest stable versions compatible with the target framework:

```bash
dotnet add <project> package Kontent.Ai.Delivery
dotnet add <models-project> package Kontent.Ai.Delivery.SourceGeneration
dotnet add <web-project> package Kontent.Ai.AspNetCore
```

Keep `Kontent.Ai.Delivery.SourceGeneration` aligned with `Kontent.Ai.Delivery`. It is packaged as a Roslyn analyzer; follow the current package/SDK documentation rather than copying analyzer metadata from an old sample project.

Do not mirror a sample application's dependency list blindly. Add caching, URL helpers, webhook support, or direct abstraction-package references only when the generated/application code or requested feature needs them.

If the latest stable package is incompatible with the target framework:

1. inspect NuGet's compatibility error and the package's supported frameworks;
2. select the newest stable compatible release when that preserves the user's target framework;
3. offer a framework upgrade as a separate choice when it would materially improve the result;
4. do not silently fall back to a prerelease.

After restore, inspect resolved direct and transitive packages using the package-list command supported by the installed SDK (`dotnet package list` or `dotnet list package`). Resolve downgrades and major-version mismatches before writing integration code.

## Configuration

Bind the SDK's standard section:

```json
{
  "DeliveryOptions": {
    "EnvironmentId": "<environment-id>",
    "UsePreviewApi": false
  }
}
```

```csharp
builder.Services.AddDeliveryClient(builder.Configuration);
```

The environment ID may be stored in ordinary configuration if the repository permits it. Store `PreviewApiKey` and `SecureAccessApiKey` in development user secrets or deployment environment variables such as `DeliveryOptions__PreviewApiKey`; never commit them.

For local secrets:

```bash
dotnet user-secrets init --project <web-project>
dotnet user-secrets set "DeliveryOptions:SecureAccessApiKey" "<key>" --project <web-project>
```

Do not place example secrets in `launchSettings.json`, tracked `appsettings*.json`, generated code, or shell scripts.

