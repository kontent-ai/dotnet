# Razor rendering

Use the `Kontent.Ai.AspNetCore` package rather than reimplementing rich-text and responsive-asset rendering.

Current primary reference: https://github.com/kontent-ai/dotnet/blob/main/src/aspnetcore/README.md

## Tag helpers

Add the Kontent.ai tag helpers to `Views/_ViewImports.cshtml`:

```razor
@addTagHelper *, Kontent.Ai.AspNetCore
```

Retain the standard MVC tag-helper registration.

## Rich text

Register the shared resolver when the application renders rich text:

```csharp
builder.Services.AddKontentRichText();
```

Keep structured rich text on the view model and render it in Razor:

```razor
@if (Model.Body is not null)
{
    <rich-text content="@Model.Body" />
}
```

The tag helper renders resolver output in place; it does not emit a `<rich-text>` wrapper.

The default resolver handles ordinary text/HTML structure and inline images. When the content model uses embedded content or content-item links, inspect those generated types and routes, then configure `IHtmlResolverBuilder` explicitly. Do not emit unencoded editor-controlled values into handcrafted HTML. Use an application route abstraction when link destinations are not trivial.

Avoid putting request-scoped state into a singleton resolver. If configuration needs DI, use the overload that exposes `IServiceProvider`, and resolve only dependencies with appropriate lifetimes or design a request-safe resolver strategy.

## Assets

Configure responsive widths only when asset rendering needs them:

```json
{
  "ImageTransformationOptions": {
    "ResponsiveWidths": [ 320, 480, 768, 1024, 1440 ]
  }
}
```

```csharp
builder.Services.Configure<ImageTransformationOptions>(
    builder.Configuration.GetSection(nameof(ImageTransformationOptions)));
```

Render a Delivery `IAsset` using `<img-asset>` and meaningful alt/title text:

```razor
<img-asset asset="@Model.HeroImage"
           title="@(Model.HeroImage.Description ?? Model.Title)"
           default-width="768" />
```

Do not hardcode transformed asset URLs when the tag helper expresses the required responsive behavior. Use explicit fixed `width`/`height` only when the layout needs a single transformed size; those attributes intentionally disable generated `srcset`/`sizes`.

## Out of scope by default

Do not add preview switching, Smart Link, webhook cache invalidation, multisite/space routing, or custom rich-text component templates merely because the sample app contains them. Add each only when requested and derive its implementation from the current SDK documentation and the target application's architecture.

