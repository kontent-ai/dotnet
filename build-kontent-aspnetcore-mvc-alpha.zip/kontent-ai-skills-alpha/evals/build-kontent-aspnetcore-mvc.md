# Alpha evaluation cases

Run each case in a fresh isolated workspace with only the skill installed. Use a disposable public Kontent.ai environment for cases that require actual generation; never point tests at an environment that the evaluator may mutate.

## 1. New plumbing-only app

> Create a new ASP.NET Core MVC app called Acme.Web and wire it to Kontent.ai environment `<environment-id>`. Generate strongly typed models, but do not invent pages from the model.

Expected invariants: standard current MVC template; stable compatible packages; local Model Generator manifest; generated models; source generation; `DeliveryOptions`; no inferred content routes; green build.

## 2. Existing MVC integration

> Add Kontent.ai Delivery to this existing MVC solution using environment `<environment-id>`. Preserve its target framework and central package management.

Expected invariants: repository conventions preserved; no incidental framework upgrade; compatible package selection; generated models compile in the intended project; unrelated files untouched.

## 3. Working content slice

> Scaffold a Kontent.ai MVC app for `<environment-id>`, then implement a listing and detail page for the generated Article content type. Keep Delivery DTO handling out of controllers and render rich text and images with the ASP.NET Core helpers.

Expected invariants: content service plus view model/mapping boundary; typed queries; cancellation; error/not-found distinction; structured rich text reaches Razor; responsive asset tag helper; no global site architecture invented.

## 4. Ambiguous model interpretation

> Build the whole website represented by this Kontent.ai environment: `<environment-id>`.

Expected behavior: explain that full site inference is beyond deterministic scaffolding; inspect enough to offer a bounded first slice or ask which routable type should be implemented. Do not silently invent navigation and URLs.

## 5. Protected environment

> Generate the MVC integration for secured environment `<environment-id>`. The secure access key is available to the agent through the approved secret channel.

Expected invariants: key is used without being printed or committed; temporary Model Generator configuration is protected and removed; application key goes to user secrets/environment configuration; green build.

## 6. Existing incompatible target

> Add the latest Kontent.ai MVC integration to this net8.0 application.

Expected behavior: inspect stable package compatibility; keep net8.0 with the newest compatible release or present framework upgrade as a user choice. Do not silently install prereleases or retarget the app.

## 7. Wrong architecture trigger

> Create a React frontend with an ASP.NET Core BFF using Kontent.ai.

Expected behavior: do not apply this MVC-specific recipe as though Razor were the presentation layer. Route to a BFF/SPA workflow or explain that a separate skill is needed.

## 8. Regeneration

> Regenerate the Kontent.ai models in this existing MVC app after the content model changed.

Expected invariants: generate to a temporary directory; preserve partial extensions; remove stale files only from an exclusively generated directory; summarize renamed/removed types; rebuild.

